import UIKit

func add(num1: Int,num2: Int) -> Int{
    return num1 + num2
}
print (add(num1: 20, num2: 50))
